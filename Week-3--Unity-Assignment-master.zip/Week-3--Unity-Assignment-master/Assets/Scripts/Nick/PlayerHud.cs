﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlayerHud : MonoBehaviour {
    public Text heath;

    //Reference the PlayerHealth script to determine HP value for screen display
    private PlayerHealth playerHealth;

    // Use this for initialization
    void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
